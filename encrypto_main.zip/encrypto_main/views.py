from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import sys
import cgi
import Crypto
from Crypto.Cipher import AES
import hashlib
import os
import random
import struct
from .encryption_methods import vigenere, aes
from django.core.files.storage import default_storage
from django.conf import settings
# Create your views here.


def index(request):
    context = {}
    template = 'encrypto/homepage.html'

    return render(request, template, context)


def about(request):
    context = {}
    template = 'encrypto/about.html'

    return render(request,template,context)


def contact(request):
    context = {}
    template = 'encrypto/contact.html'

    return render(request,template,context)


def algorithms(request):
    context = {}
    template = 'encrypto/algorithms.html'

    return render(request,template,context)


def downloadfile(request):
    context = {}
    template = 'encrypto/downloadfile.html'

    return render(request,template,context)


def downloadpwa(request):
    context = {}
    template = 'encrypto/downloadpwa.html'

    return render(request,template,context)


def downloadredirect(request):
    context = {}
    template = 'encrypto/downloadredirect.html'

    return render(request,template,context)


def encrypt(request):
    context = {}
    template = 'encrypto/encrypt.html'

    return render(request,template,context)


def homepage(request):
    context = {}
    template = 'encrypto/homepage.html'

    return render(request,template,context)


def login(request):
    context = {}
    template = 'encrypto/login.html'
    return render(request,template,context)


def testing(request):
    context={}
    template = 'encrypto/Test.html'
    return render(request,template,context)


def encrypt_files(request):
    #Take the form data and saves the file.
    template = 'encrypto/encrypt_file.html'

    algorithms = [
        "Triple Des",
        "AES",
        "One Time Pad",
        "Vigenere"
    ]

    context = { 'algorithms': algorithms }
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        algorithm = request.POST.get('algorithm_select')

        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        uploaded_file_location = fs.path(filename)
        filedata = ''
        for line in myfile:
            print(line)
            filedata += str(line)
        ciphertext = ''
        if algorithm == "Triple Des":
            #encrypt with Triple DES
            pass
        elif algorithm == "AES":
            #encrypt with AES
            ciphertext = aes.encrypt(filedata, "aw",uploaded_file_location)

        elif algorithm == "One Time Pad":
            pass
        else:
            #encrypt with Vigenere
            # vigenere.encrypt(string, key)
            ciphertext = vigenere.vigenere_encrypt(filedata, "aw")
            file = open(uploaded_file_location, "w")
            file.write(ciphertext)
            file.close()
        #filedata = encrypt_file_diffie(5, filedata)
        
        context = { 
            "ciphertext": ciphertext,
            "the_data": algorithm,
            'uploaded_file_url': uploaded_file_url
        }
        print(myfile.read())
        return render(request, template, context)
    return render(request, template, context)

def decrypt_files(request):
    template = 'encrypto/decrypt_file.html'
    context = {}
    if request.method == 'POST' and request.FILES['myfile']:
        print("In HERE")
        return render(request, template, context)
    return render(request, template, context)