from django.apps import AppConfig


class EncryptoMainConfig(AppConfig):
    name = 'encrypto_main'
