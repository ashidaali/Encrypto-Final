from django.contrib import admin
from django.urls import path
from django.urls import include
from . import views

urlpatterns = [
    path('accounts/', include('django.contrib.auth.urls')),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('algorithms', views.algorithms, name='algorithms'),
    path('downloadfile', views.downloadfile, name='downloadfile'),
    path('downloadpwa', views.downloadpwa, name='downloadpwa'),
    path('downloadredirect', views.downloadredirect, name='downloadredirect'),
    path('encrypt', views.encrypt, name='encrypt'),
    #path('login', views.login, name='login'),
    path('testing', views.testing, name='test'),
    path('encrypt_files', views.encrypt_files, name='encrypt_files'),
    path('decrypt_files', views.decrypt_files, name='decrypt_files'),
    path('homepage', views.homepage,  name='homepage'),
    path('', views.index, name='index')
    # Have to add in auxillary Login functions here https://wsvincent.com/django-user-authentication-tutorial-login-and-logout/
]
