from random import *
import numpy

def random_bitstring(binaryConv):
    """Random Bitstring Generator"""
    binaryConv = binaryConv
    key = numpy.random.randint(2, size=int(binaryConv.bit_length()))
    return key

def xor(key, binaryConv, uploaded_file_url):
    """XOR key and data"""
    key = key
    binaryConv = binaryConv
    x = int(key,2) ^ int(binaryConv,2)
    y = format(x, 'b')
    return y

def encrypt(uploaded_file_url): 
    def binary(uploaded_file_url):
        """Open file to read"""
        file = open(uploaded_file_url, "r")
        binaryConv = file.read()
        file.close()

        """Convert contents of file to ascii then binary"""
        binaryConv = bytes(filedata, "ascii")
        binaryConv = "".join(["{0:b}".format(x) for x in binaryConv])
        return binaryConv

    binary("/uploaded_file_url/filename.txt")

    """Generate random key"""
    random_bitstring(binaryConv)

    """Perform xor"""
    xor(key, binaryConv, "/uploaded_file_url/filename.txt")

    """Overwrite file"""
    file = open(uploaded_file_url, "w")
    file.write(y)
    file.close()

# encrypt("/uploaded_file_url/filename.txt")

def decrypt(uploaded_file_url):
    """Open file to read"""
    file = open(uploaded_file_url, "r")
    binaryConv = file.read()
    file.close()

    """Generate random key"""
    random_bitstring(binaryConv)

    xor(key, binaryConv, "/uploaded_file_url/filename.txt")

    def bitstring(y, uploaded_file_url):
        """Convert bits back to string"""
        y = y
        y = y.decode("ascii")
        """Overwrite file"""
        file = open(uploaded_file_url, "w")
        file.write(y)
        file.close()
        return y

    bitstring(y, "/uploaded_file_url/filename.txt")

# decrypt("/uploaded_file_url/filename.txt")
