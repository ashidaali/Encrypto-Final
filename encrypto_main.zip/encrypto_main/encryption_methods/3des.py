from Crypto.Cipher import DES3
from Crypto.Random import get_random_bytes
from pyDes import *

while True:
    try:
        key = DES3.adjust_key_parity(get_random_bytes(24))
        break
    except ValueError:
        pass

# """Open file to read"""
# file = open("/uploaded_file_url/filename.txt", "r")
# string = file.read()
# file.close()

def encrypt(string, key, uploaded_file_url):
    """3DES Encrypt"""
    cipher_key = DES3.new(key, DES3.MODE_CFB)
    ciphertext = cipher_key.nonce + cipher_key.encrypt(string)

    """Overwrite file"""
    file = open(uploaded_file_url, "w")
    file.write(ciphertext)
    file.close()
    return ciphertext

#encrypt(string, key, "/uploaded_file_url/filename.txt")

def decrypt(string, uploaded_file_url):
    """3DES Decryption"""
    cipher_key = des("DESCRYPT", CBC, "\0\0\0\0\0\0\0\0", pad=None, padmode=PAD_PKCS5)
    decrypted = cipher_key.decrypt(string)

    """Overwrite file"""
    file = open(uploaded_file_url, "w")
    file.write(decrypted)
    file.close()
    return decrypted

#decrypt(string, "/uploaded_file_url/filename.txt")

