import pyaes
import requests
import random


# """Get random key from dictionary"""
# word_site = "http://svnweb.freebsd.org/csrg/share/dict/words?view=co&content-type=text/plain"
# response = requests.get(word_site)
# WORDS = response.content.splitlines()
# word = random.choice(WORDS)
# key = word

# key = "encrypto"

# """Convert key to bytes"""
# key = key.encode('utf-8')
# aes = pyaes.AESModeOfOperationCTR(key) 

def encrypt(string, key, uploaded_file_url):
    #salt="BBB60C350A368415"
    key="EB6E1F16D48403FBDBDF8B29831FD6B3"
    #iv ="0E4BBB9F910C4C38CE9DDF43750F84B6"
    key = key.encode('utf-8')
    aes = pyaes.AESModeOfOperationCTR(key)
    """AES encryption"""      
    ciphertext = str(aes.encrypt(string))

    """Overwrite file"""
    file = open(uploaded_file_url, "w")
    file.write(ciphertext)
    file.close()
    return ciphertext

#encrypt(string, key, "/uploaded_file_url/filename.txt")

def decrypt(string, key, uploaded_file_url):
    #salt="BBB60C350A368415"
    key="EB6E1F16D48403FBDBDF8B29831FD6B3"
    #iv ="0E4BBB9F910C4C38CE9DDF43750F84B6"
    key = key.encode('utf-8')
    aes = pyaes.AESModeOfOperationCTR(key)
    """AES Decryption"""
    decrypted = aes.decrypt(string).decode('utf-8')

    """Overwrite file"""
    file = open(uploaded_file_url, "w")
    file.write(decrypted)
    file.close()
    return decrypted

#decrypt(string, key, "/uploaded_file_url/filename.txt")
